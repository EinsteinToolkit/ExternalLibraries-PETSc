!
!  Include file for Fortran use of the DT package in PETSc
!
#if !defined (PETSCDTDEF_H)
#define PETSCDTDEF_H

#define PetscDTNodeType PetscEnum

#endif
