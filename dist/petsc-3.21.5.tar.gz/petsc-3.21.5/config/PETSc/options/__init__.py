all = ['BLAS', 'ML', 'LAPACK', 'MPI', 'Mathematica', 'Matlab', 'metis', 'parmetis', 'Triangle']
