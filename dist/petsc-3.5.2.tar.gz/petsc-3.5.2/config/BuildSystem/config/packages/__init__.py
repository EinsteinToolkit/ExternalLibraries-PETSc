all = ['make','fblaslapack','f2cblaslapack','BlasLapack','exodusii', 'scientificpython', 'fiat', 'MOAB', 'MPI', 'netcdf', 'PETSc','boost', 'cusp', 'thrust', 'hdf5', 'netcdf-cxx', 'cgns']
